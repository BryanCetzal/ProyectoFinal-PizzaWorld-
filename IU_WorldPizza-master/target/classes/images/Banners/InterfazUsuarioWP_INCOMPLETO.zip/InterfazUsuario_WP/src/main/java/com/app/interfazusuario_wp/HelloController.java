package com.app.interfazusuario_wp;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


import java.io.IOException;
import java.util.Objects;

public class HelloController {
    private int numOrden = 1;
    private boolean orderBandera;

    @FXML
    private HBox fila1;
    @FXML
    private Label pizzaElegida, pizzaElegida1, pizzaElegida2, pizzaElegida3, pizzaElegida4;
    @FXML
    private Label refrescoElegido, refrescoElegido1, refrescoElegido2, refrescoElegido3, refrescoElegido4;
    @FXML
    private Label ordenElegido;
    @FXML
    private Label domicilio;
    @FXML
    private AnchorPane logoPanel;
    @FXML
    private AnchorPane menuPanel;

    @FXML
    private AnchorPane orderDomiPanel;

    @FXML
    private AnchorPane carPanel;

    @FXML
    private AnchorPane menuPizzasPanel;

    @FXML
    private AnchorPane menuBebidasPanel;

    @FXML
    private AnchorPane orderTiendaPanel;

    @FXML
    private AnchorPane ModoCompraPanel;
    @FXML
    private TextField nombreCli;

    @FXML
    private TextField tel;

    @FXML
    private TextField apellido;

    @FXML
    private TextField colonia;

    @FXML
    private TextField calle;

    @FXML
    private TextField numExt;

    @FXML
    private TextField cruz1;

    @FXML
    private TextField cruz2;

    @FXML
    private TextField referencias;
    public void exit(MouseEvent event){
        Platform.exit();
        System.exit(0);
    }
    public void main(MouseEvent event){
        logoPanel.setVisible(true);

        menuPanel.setVisible(false);
        ModoCompraPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);
    }

    public void menu(MouseEvent event){
        menuPanel.setVisible(true);

        logoPanel.setVisible(false);
        ModoCompraPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);
    }
            public void menuPiz(MouseEvent event){
                menuPizzasPanel.setVisible(true);

                logoPanel.setVisible(false);
                ModoCompraPanel.setVisible(false);
                carPanel.setVisible(false);
                orderTiendaPanel.setVisible(false);
                orderDomiPanel.setVisible(false);
                menuPanel.setVisible(false);
                menuBebidasPanel.setVisible(false);
            }
            public void menuBeb(MouseEvent event){
                menuBebidasPanel.setVisible(true);

                logoPanel.setVisible(false);
                ModoCompraPanel.setVisible(false);
                carPanel.setVisible(false);
                orderTiendaPanel.setVisible(false);
                orderDomiPanel.setVisible(false);
                menuPizzasPanel.setVisible(false);
                menuPanel.setVisible(false);
            }
    public void order(MouseEvent event){
        ModoCompraPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);
    }
            public void entregaDomi(MouseEvent event){
                orderDomiPanel.setVisible(true);

                logoPanel.setVisible(false);
                menuPanel.setVisible(false);
                ModoCompraPanel.setVisible(false);
                orderTiendaPanel.setVisible(false);
                carPanel.setVisible(false);
                menuPizzasPanel.setVisible(false);
                menuBebidasPanel.setVisible(false);

                ordenElegido.setText("Entregar a domicilio.");
                orderBandera = true;
            }
            public void entregaTienda(MouseEvent event){
                orderTiendaPanel.setVisible(true);

                logoPanel.setVisible(false);
                menuPanel.setVisible(false);
                ModoCompraPanel.setVisible(false);
                carPanel.setVisible(false);
                orderDomiPanel.setVisible(false);
                menuPizzasPanel.setVisible(false);
                menuBebidasPanel.setVisible(false);

                ordenElegido.setText("Entregar en Tienda.");
                orderBandera = true;
            }
    public void car(MouseEvent event){
        carPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        ModoCompraPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);
    }
    public void orden1(MouseEvent event){
        numOrden = 1;

        if(Objects.equals(pizzaElegida1.getText(), "Vacío")){
            pizzaElegida.setText("Ninguna.");
        }else{
            pizzaElegida.setText(pizzaElegida1.getText());
        }
        if(Objects.equals(refrescoElegido1.getText(), "Vacío")){
            refrescoElegido.setText("Ninguno.");
        }else{
            refrescoElegido.setText(refrescoElegido1.getText());
        }
    }
    public void orden2(MouseEvent event){
        numOrden = 2;
        if(Objects.equals(pizzaElegida2.getText(), "Vacío")){
            pizzaElegida.setText("Ninguna.");
        }else{
            pizzaElegida.setText(pizzaElegida2.getText());
        }
        if(Objects.equals(refrescoElegido2.getText(), "Vacío")){
            refrescoElegido.setText("Ninguno.");
        }else{
            refrescoElegido.setText(refrescoElegido2.getText());
        }
    }
    public void orden3(MouseEvent event){
        numOrden = 3;
        if(Objects.equals(pizzaElegida3.getText(), "Vacío")){
            pizzaElegida.setText("Ninguna.");
        }else{
            pizzaElegida.setText(pizzaElegida3.getText());
        }
        if(Objects.equals(refrescoElegido3.getText(), "Vacío")){
            refrescoElegido.setText("Ninguno.");
        }else{
            refrescoElegido.setText(refrescoElegido3.getText());
        }
    }
    public void orden4(MouseEvent event){
        numOrden = 4;
        if(Objects.equals(pizzaElegida4.getText(), "Vacío")){
            pizzaElegida.setText("Ninguna.");
        }else{
            pizzaElegida.setText(pizzaElegida4.getText());
        }
        if(Objects.equals(refrescoElegido4.getText(), "Vacío")){
            refrescoElegido.setText("Ninguno.");
        }else{
            refrescoElegido.setText(refrescoElegido4.getText());
        }
    }

    public void orderPiMex(MouseEvent event)  {
        ModoCompraPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);

        if (numOrden == 1){
            pizzaElegida1.setText("Pizza Mexicana.");
            pizzaElegida.setText(pizzaElegida1.getText());
        }
        if (numOrden == 2){
            pizzaElegida2.setText("Pizza Mexicana.");
            pizzaElegida.setText(pizzaElegida2.getText());
        }
        if (numOrden == 3){
            pizzaElegida3.setText("Pizza Mexicana.");
            pizzaElegida.setText(pizzaElegida3.getText());
        }
        if (numOrden == 4){
            pizzaElegida3.setText("Pizza Mexicana.");
            pizzaElegida.setText(pizzaElegida4.getText());
        }

        orderBandera = true;
    }
    public void orderPiHaw(MouseEvent event)  {
        ModoCompraPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);

        if (numOrden == 1){
            pizzaElegida1.setText("Pizza Hawaiana.");
            pizzaElegida.setText(pizzaElegida1.getText());
        }
        if (numOrden == 2){
            pizzaElegida2.setText("Pizza Hawaiana.");
            pizzaElegida.setText(pizzaElegida2.getText());
        }
        if (numOrden == 3){
            pizzaElegida3.setText("Pizza Hawaiana.");
            pizzaElegida.setText(pizzaElegida3.getText());
        }
        if (numOrden == 4){
            pizzaElegida3.setText("Pizza Hawaiana.");
            pizzaElegida.setText(pizzaElegida4.getText());
        }
        orderBandera = true;
    }

    public void orderPiPep(MouseEvent event)  {
        ModoCompraPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);

        if (numOrden == 1){
            pizzaElegida1.setText("Pizza de Pepperoni.");
            pizzaElegida.setText(pizzaElegida1.getText());
        }
        if (numOrden == 2){
            pizzaElegida2.setText("Pizza de Pepperoni.");
            pizzaElegida.setText(pizzaElegida2.getText());
        }
        if (numOrden == 3){
            pizzaElegida3.setText("Pizza de Pepperoni.");
            pizzaElegida.setText(pizzaElegida3.getText());
        }
        if (numOrden == 4){
            pizzaElegida4.setText("Pizza de Pepperoni.");
            pizzaElegida.setText(pizzaElegida4.getText());
        }
        orderBandera = true;
    }

    public void orderPiPas(MouseEvent event)  {
        ModoCompraPanel.setVisible(true);

        logoPanel.setVisible(false);
        menuPanel.setVisible(false);
        carPanel.setVisible(false);
        orderTiendaPanel.setVisible(false);
        orderDomiPanel.setVisible(false);
        menuPizzasPanel.setVisible(false);
        menuBebidasPanel.setVisible(false);

        if (numOrden == 1){
            pizzaElegida1.setText("Pizza de Pástor.");
            pizzaElegida.setText(pizzaElegida1.getText());
        }
        if (numOrden == 2){
            pizzaElegida2.setText("Pizza de Pástor.");
            pizzaElegida.setText(pizzaElegida2.getText());
        }
        if (numOrden == 3){
            pizzaElegida3.setText("Pizza de Pástor.");
            pizzaElegida.setText(pizzaElegida3.getText());
        }
        if (numOrden == 4){
            pizzaElegida4.setText("Pizza de Pástor.");
            pizzaElegida.setText(pizzaElegida4.getText());
        }

        orderBandera = true;
    }
    public void orderRefCo(MouseEvent event)  {
        refrescoElegido.setText("Coca-Cola.");
        if (numOrden == 1){
            refrescoElegido1.setText("Coca-Cola.");
            refrescoElegido.setText(refrescoElegido1.getText());
        }
        if (numOrden == 2){
            refrescoElegido2.setText("Coca-Cola.");
            refrescoElegido.setText(refrescoElegido2.getText());
        }
        if (numOrden == 3){
            refrescoElegido3.setText("Coca-Cola.");
            refrescoElegido.setText(refrescoElegido3.getText());
        }
        if (numOrden == 4){
            refrescoElegido4.setText("Coca-Cola.");
            refrescoElegido.setText(refrescoElegido4.getText());
        }
        orderBandera = true;
    }
    public void orderRefPep(MouseEvent event)  {
        if (numOrden == 1){
            refrescoElegido1.setText("Pepsi.");
            refrescoElegido.setText(refrescoElegido1.getText());
        }
        if (numOrden == 2){
            refrescoElegido2.setText("Pepsi.");
            refrescoElegido.setText(refrescoElegido2.getText());
        }
        if (numOrden == 3){
            refrescoElegido3.setText("Pepsi.");
            refrescoElegido.setText(refrescoElegido3.getText());
        }
        if (numOrden == 4){
            refrescoElegido4.setText("Pepsi.");
            refrescoElegido.setText(refrescoElegido4.getText());
        }
        orderBandera = true;
    }
    public void orderRefMun(MouseEvent event)  {
        if (numOrden == 1){
            refrescoElegido1.setText("Mundet.");
            refrescoElegido.setText(refrescoElegido1.getText());
        }
        if (numOrden == 2){
            refrescoElegido2.setText("Mundet.");
            refrescoElegido.setText(refrescoElegido2.getText());
        }
        if (numOrden == 3){
            refrescoElegido3.setText("Mundet.");
            refrescoElegido.setText(refrescoElegido3.getText());
        }
        if (numOrden == 4){
            refrescoElegido4.setText("Mundet.");
            refrescoElegido.setText(refrescoElegido4.getText());
        }
        orderBandera = true;
    }

    public void guardar(MouseEvent event){
        domicilio.setText("Nombre: " + nombreCli.getText() + " " + apellido.getText() + "\n" +
        "Teléfono: " + tel.getText() + "\n" +
        "Dirección: Colonia " + colonia.getText() + ", calle " + calle.getText() + " #" + numExt.getText() + " entre " +
                cruz1.getText() + " y " + cruz2.getText() + "\n" +
        "Referencias: " + referencias.getText());
    }
}